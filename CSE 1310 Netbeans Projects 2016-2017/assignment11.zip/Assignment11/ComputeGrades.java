
import java.util.Scanner;
import java.util.ArrayList;
import java.io.File;
import java.io.PrintWriter;

public class ComputeGrades
{
    
    public static void processGrades(String input_name, String csv_name, String pretty_name)
    {
        String[][] data = readSpreadsheet(input_name);
        String filename = csv_name;
        PrintWriter out = null;
        if(data == null){
            System.out.printf("Sanity check: null data\n");
            System.out.printf("Sanity check failed.\n");
            System.out.printf("\nExiting...\n");
            System.exit(0);
        }
            
        else if (data.length == 0){
            System.out.printf("Sanity check: %d rows\n", data.length);
            System.out.printf("Sanity check failed\n.");
            System.out.printf("\nExiting...\n");
            System.exit(0);
        }
        
        else if (data.length == 1){
            System.out.printf("Sanity check: %d rows\n", data.length);
            System.out.printf("Sanity check failed.\n");
            System.out.printf("\nExiting...\n");
            System.exit(0);
        }
       
        for(int i = 0; i < data.length; i++)
        {
            if(data[i].length != 12)
            {
                System.out.printf("Sanity check: %d columns at row %d\n", data[i].length, i);
                System.out.printf("Sanity check failed.\n");
                System.out.printf("\nExiting...\n");
                System.exit(0);
            }
            
        }
        
        for(int z = 1; z < data.length; z++) //Starts at row 1
        {
            for(int j = 2; j < data[z].length; j++) //Starts at column 2
            {
                try
                {
                    Double.parseDouble(data[z][j]);
                }
                catch(Exception e)
                {
                    System.out.printf("Non-number found: %s. row = %d, col = %d\n",data[z][j], z, j);
                    System.out.println("Samity check failed");
                    System.out.printf("\nExiting...\n");
                    System.exit(0);
                }
            }
        }
        try
        {
            out = new PrintWriter(filename);
        }
        catch (Exception e)
        {
            System.out.printf("Error: failed to open file %s.\n", filename);
            System.exit(0);
        }
        out.printf("name,exam_score,hw_score,min_score,grade\r\n");
        
        
        for(int i = 1; i < data.length; i++) //loop begins at row 1
        {
            String first = data[i][0];
            String last = data[i][1];
            double e1 = Double.parseDouble(data[i][2]);
            double e2 = Double.parseDouble(data[i][3]);
            double f = Double.parseDouble(data[i][4]);
            double h1 = Double.parseDouble(data[i][5]);
            double h2 = Double.parseDouble(data[i][6]);
            double h3 = Double.parseDouble(data[i][7]);
            double h4 = Double.parseDouble(data[i][8]);
            double h5 = Double.parseDouble(data[i][9]);
            double h6 = Double.parseDouble(data[i][10]);
            double h7 = Double.parseDouble(data[i][11]);
            double sum = (e1 + e2 + f)/3;
            double sum2 = (h1 + h2 + h3 + h4 + h5 + h6 + h7)/7;
            double min = 0;
            String grade = "";
            if(sum < sum2)
            {
                min = sum;
            }
            else
            {
                min = sum2;
            }
            if(min >= 90)
            {
                grade = "A";
            }
            else if(min < 90 && min >= 80)
            {
                grade = "B";
            }
            else if(min < 80 && min >= 70)
            {
                grade = "C";
            }
            else if(min < 70 && min >= 60)
            {
                grade = "D";
            }
            else
            {
                grade = "F";
            }
            out.printf("%s %s,%.6f,%.6f,%.6f,%s\r\n", first, last, sum, sum2, min,grade);
        }
        out.close();
        
        String file = pretty_name;
        PrintWriter out2 = null;
        try
        {
            out2 = new PrintWriter(file);
        }
        catch (Exception e)
        {
            System.out.printf("Error: failed to open file %s.\n", filename);
            System.exit(0);
        }
        String n = "name";
        out2.printf("%20s: exam_score, hw_score, min_score, grade\r\n", n);
        
        
        for(int i = 1; i < data.length; i++) //loop begins at row 1
        {
            String first = data[i][0];
            String last = data[i][1];
            double e1 = Double.parseDouble(data[i][2]);
            double e2 = Double.parseDouble(data[i][3]);
            double f = Double.parseDouble(data[i][4]);
            double h1 = Double.parseDouble(data[i][5]);
            double h2 = Double.parseDouble(data[i][6]);
            double h3 = Double.parseDouble(data[i][7]);
            double h4 = Double.parseDouble(data[i][8]);
            double h5 = Double.parseDouble(data[i][9]);
            double h6 = Double.parseDouble(data[i][10]);
            double h7 = Double.parseDouble(data[i][11]);
            double sum = (e1 + e2 + f)/3;
            double sum2 = (h1 + h2 + h3 + h4 + h5 + h6 + h7)/7;
            double min = 0;
            String grade = "";
            if(sum < sum2)
            {
                min = sum;
            }
            else
            {
                min = sum2;
            }
            if(min >= 90)
            {
                grade = "A";
            }
            else if(min < 90 && min >= 80)
            {
                grade = "B";
            }
            else if(min < 80 && min >= 70)
            {
                grade = "C";
            }
            else if(min < 70 && min >= 60)
            {
                grade = "D";
            }
            else
            {
                grade = "F";
            }
            out2.printf("%20s: %10.2f, %8.2f, %9.2f, %s\r\n", first+" "+last, sum, sum2, min,grade);
        }
        out2.close();
    }
  public static String[][] readSpreadsheet(String filename)
  {
    ArrayList<String> lines = readFile(filename);
    if (lines == null)
    {
      return null;
    }

    int rows = lines.size();
    String[][] result = new String[rows][];

    for (int i = 0; i < rows; i++)
    {
      String line = lines.get(i);
      String[] values = line.split(",");
      result[i] = values;
    }

    return result;
  }

  public static ArrayList<String> readFile(String filename)
  {
    File temp = new File(filename);
    Scanner input_file;

    try
    {
      input_file = new Scanner(temp);
    } catch (Exception e)
    {
      System.out.printf("Failed to open file %s\n",
              filename);
      return null;
    }

    ArrayList<String> result = new ArrayList<String>();
    while (input_file.hasNextLine())
    {
      String line = input_file.nextLine();
      result.add(line);
    }

    input_file.close();
    return result;
  }

  public static void main(String[] args)
  {
    Scanner in = new Scanner(System.in);

    System.out.printf("Please enter the name of the input file: ");
    String input_name = in.next();
    System.out.printf("Please enter the name of the output CSV file: ");
    String csv_name = in.next();
    System.out.printf("Please enter the name of the output pretty-print file: ");
    String pretty_name = in.next();

    processGrades(input_name, csv_name, pretty_name);
    System.out.printf("\nExiting...\n");
  }
}