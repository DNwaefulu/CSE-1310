import java.util.Scanner;

public class task6 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.printf("When is the first Sunday this March? ");
        int date = in.nextInt();
        
        if(date > 0 && date < 8)
        {
            System.out.println("This March, Sundays fall on: ");
            for(int d = date; d <= 31; d += 7)
            {
                System.out.printf("March %d\n", d);
            }  
        }
        else
        {
            System.out.println("invalid entry");
        }
    }
}
