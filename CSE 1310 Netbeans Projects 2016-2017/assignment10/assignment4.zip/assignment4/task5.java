import java.util.Scanner;

public class task5
{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
                       
        System.out.printf("Enter a word: ");
        String word = in.nextLine();
        
        for (int i = 0; i < word.length(); i++)
        {
            char vowel = word.charAt(i);
            if((vowel != 'A') && (vowel != 'a') && (vowel != 'E') && (vowel != 'e') && (vowel != 'I') && (vowel != 'i') && 
                    (vowel != 'O') && (vowel != 'o') && (vowel != 'U') && (vowel != 'u') )
            {
                System.out.printf("%c", word.charAt(i));
            }
        }
        System.out.println("\nExiting...");
    }
}