import java.util.Scanner;

public class task9 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.printf("Enter a positive integer N > 0: ");
        int N = in.nextInt();
        
        if(N > 0)
        {
            for(int i = 0; i < N; i++ )
            {
                for(int z = 0; z < i; z++ )
                {
                    System.out.printf("*");
                }
                System.out.println("");
            }
            System.out.println("Exiting...");
        }
        else
        {
            System.out.println("Exiting...");
        }
    }
}
