import java.util.Scanner;

public class task8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        System.out.printf("Enter a positive integer N > 1: ");
        double N = in.nextDouble();
        double o7 = 0;
        double d = 0;
        
        if(N > 0)
        {
            for(double i = 0; d <= 40000; i++)
            {
                o7 = Math.pow(N, i);
                d = Math.pow(N, i+1);
                System.out.printf("%.0f\n", o7);
            }
            System.out.println("Exiting...");
        }
        else
        {
            System.out.println("Exiting...");
        }
    }
    
}
